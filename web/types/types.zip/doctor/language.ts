export interface language {
  name: string;
  description: string;
}
