import { lang } from "./lang";

export interface institution {
  _id: string;
  institutionName: string;
  lang: lang
}
