export interface service {
  _id: string;
  title: string;
  description: string;
  lang: {
    am: {
      title: string;
      description: string;
    };
  };
}
