// get connected
export const getConnected = [
  {
    linkName: "For Physicians",
    linkPath: "#",
  },
  {
    linkName: "For Hospitala",
    linkPath: "#",
  },
];

// Actions
export const actions = [
  {
    linkName: "Find a doctor",
    linkPath: "#",
  },
  {
    linkName: "Find a hospital",
    linkPath: "#",
  },
];

// company
export const company = [
  {
    linkName: "About Us",
    linkPath: "#",
  },
  {
    linkName: "Career",
    linkPath: "#",
  },
  {
    linkName: "Join our team",
    linkPath: "#",
  },
];
