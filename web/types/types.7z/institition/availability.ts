export interface availability {
  twentyFourHours: true;
  startDay: string;
  endDay: string;
  opening: string;
  closing: string;
}
